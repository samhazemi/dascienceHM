

```python
import tweepy
import json
import pandas as pd
import numpy as np
import time
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()
```


```python
consumer_key = 'e1s1DYp74uStIW5L7mvytx5Z7'
consumer_secret = '9R5ZyqjIrlIoEyJM1UOfUjANuHI6g7emju8KC1GF3tZf3e2tR6'
access_token = '47794770-8AsFjEEKXveZAa2QFIpCllIzVq8f9JwERU9yEyFI6'
access_token_secret = 'YUAmKAxlmKLUV3GH9UNpXax01QDqmGIJmbiQQlHho3V45'
```


```python
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())
```


```python
sentiments = []

target_users = ("@BBC", "@CBS", "@CNN", "@FoxNews", "@NYTimes")


for user in target_users:
    
    

    counter = 0
    
    

    
    public_tweets = api.user_timeline(user, count = 100)

        
    for tweet in public_tweets:

        
        compound = analyzer.polarity_scores(tweet["text"])["compound"]
        pos = analyzer.polarity_scores(tweet["text"])["pos"]
        neu = analyzer.polarity_scores(tweet["text"])["neu"]
        neg = analyzer.polarity_scores(tweet["text"])["neg"]
        tweets_ago = counter
        tweet_text = tweet["text"]

        
        sentiments.append({"User" : user,
                           "Date": tweet["created_at"],
                           "Compound" : compound,
                           "Positive" : pos,
                           "Negative" : neg,
                           "Neutral" : neu,
                           "Tweets Ago" : counter,
                           "Tweet Text" : tweet_text})
        

        counter = counter + 1
```


```python
news_sentiments = pd.DataFrame.from_dict(sentiments)
news_sentiments

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Tweet Text</th>
      <th>Tweets Ago</th>
      <th>User</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.8625</td>
      <td>Sat Mar 17 14:00:30 +0000 2018</td>
      <td>0.000</td>
      <td>0.699</td>
      <td>0.301</td>
      <td>⛷❤️ George has autism and other health conditi...</td>
      <td>0</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.3628</td>
      <td>Sat Mar 17 13:46:15 +0000 2018</td>
      <td>0.073</td>
      <td>0.784</td>
      <td>0.143</td>
      <td>RT @5liveSport: 'My mates didn't know I was pl...</td>
      <td>1</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.4019</td>
      <td>Sat Mar 17 13:00:08 +0000 2018</td>
      <td>0.000</td>
      <td>0.881</td>
      <td>0.119</td>
      <td>Yes, Gary Oldman and @BBCEastEnders' Big Mo ar...</td>
      <td>2</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-0.7244</td>
      <td>Sat Mar 17 12:39:41 +0000 2018</td>
      <td>0.336</td>
      <td>0.664</td>
      <td>0.000</td>
      <td>RT @BBCOne: .@NiallOfficial won't let fame get...</td>
      <td>3</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.5106</td>
      <td>Sat Mar 17 12:00:09 +0000 2018</td>
      <td>0.112</td>
      <td>0.643</td>
      <td>0.245</td>
      <td>♻️🗑 This shop encourages you to bring your own...</td>
      <td>4</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.8883</td>
      <td>Sat Mar 17 11:30:09 +0000 2018</td>
      <td>0.000</td>
      <td>0.488</td>
      <td>0.512</td>
      <td>🇮🇪 🍀 Celebrate #StPatricksDay in true Irish st...</td>
      <td>5</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.6249</td>
      <td>Sat Mar 17 11:03:05 +0000 2018</td>
      <td>0.000</td>
      <td>0.796</td>
      <td>0.204</td>
      <td>From scrambled eggs to chilli-spiced crisps: h...</td>
      <td>6</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.6996</td>
      <td>Sat Mar 17 10:14:25 +0000 2018</td>
      <td>0.066</td>
      <td>0.658</td>
      <td>0.276</td>
      <td>RT @BBCTwo: Happy #StPatricksDay! Check out wh...</td>
      <td>7</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.0000</td>
      <td>Sat Mar 17 10:00:02 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>🎶🐦 Did you know that bullfinches can learn to ...</td>
      <td>8</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>9</th>
      <td>-0.7717</td>
      <td>Sat Mar 17 09:39:19 +0000 2018</td>
      <td>0.251</td>
      <td>0.749</td>
      <td>0.000</td>
      <td>RT @BBCEngland: Stephen Hawking's PhD thesis h...</td>
      <td>9</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.6369</td>
      <td>Sat Mar 17 09:00:06 +0000 2018</td>
      <td>0.000</td>
      <td>0.714</td>
      <td>0.286</td>
      <td>Ready to get active?\n🏃 Here are 5 ways you ca...</td>
      <td>10</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.7783</td>
      <td>Fri Mar 16 19:38:34 +0000 2018</td>
      <td>0.000</td>
      <td>0.726</td>
      <td>0.274</td>
      <td>RT @BBCR1: This guy just raised over a million...</td>
      <td>11</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.4926</td>
      <td>Fri Mar 16 18:31:01 +0000 2018</td>
      <td>0.000</td>
      <td>0.610</td>
      <td>0.390</td>
      <td>💪😲⚽️ Keepy-uppy the good work! https://t.co/lF...</td>
      <td>12</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.5719</td>
      <td>Fri Mar 16 17:00:25 +0000 2018</td>
      <td>0.000</td>
      <td>0.791</td>
      <td>0.209</td>
      <td>❤️🎧 Bradley has never let Asperger's hold him ...</td>
      <td>13</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.0000</td>
      <td>Fri Mar 16 16:30:01 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Running for the door on a Friday afternoon lik...</td>
      <td>14</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.0000</td>
      <td>Fri Mar 16 16:00:00 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>🔊🎵Jarvis Cocker describes the dream-like exper...</td>
      <td>15</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.0000</td>
      <td>Fri Mar 16 14:25:15 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>RT @BBCR1: The gruelling task of climbing Ben ...</td>
      <td>16</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.3400</td>
      <td>Fri Mar 16 14:00:13 +0000 2018</td>
      <td>0.000</td>
      <td>0.841</td>
      <td>0.159</td>
      <td>Prepare to get that warm fuzzy feeling - the m...</td>
      <td>17</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.6124</td>
      <td>Fri Mar 16 12:59:01 +0000 2018</td>
      <td>0.000</td>
      <td>0.667</td>
      <td>0.333</td>
      <td>🤔🎨 Why are soap bubbles such gorgeous colours?...</td>
      <td>18</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.3612</td>
      <td>Fri Mar 16 12:38:40 +0000 2018</td>
      <td>0.000</td>
      <td>0.902</td>
      <td>0.098</td>
      <td>RT @BBCNewsPR: Get ready to make the headlines...</td>
      <td>19</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>20</th>
      <td>-0.6486</td>
      <td>Fri Mar 16 12:00:04 +0000 2018</td>
      <td>0.238</td>
      <td>0.762</td>
      <td>0.000</td>
      <td>😂 Fights, funerals, and giant furry heads... @...</td>
      <td>20</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.5574</td>
      <td>Fri Mar 16 10:45:24 +0000 2018</td>
      <td>0.000</td>
      <td>0.841</td>
      <td>0.159</td>
      <td>RT @BBCRadio2: It's with a heavy heart that to...</td>
      <td>21</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0.0000</td>
      <td>Fri Mar 16 10:02:00 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Are you getting enough sleep? This simple test...</td>
      <td>22</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.4939</td>
      <td>Fri Mar 16 09:35:56 +0000 2018</td>
      <td>0.000</td>
      <td>0.814</td>
      <td>0.186</td>
      <td>RT @bbcthree: the dancing in taylor swift's ne...</td>
      <td>23</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.6486</td>
      <td>Fri Mar 16 09:35:50 +0000 2018</td>
      <td>0.000</td>
      <td>0.813</td>
      <td>0.187</td>
      <td>RT @BBCEngland: Oscar-winning British short fi...</td>
      <td>24</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.0000</td>
      <td>Fri Mar 16 09:35:47 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>RT @BBCScotlandNews: Meet Chloe - the five-yea...</td>
      <td>25</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.4939</td>
      <td>Fri Mar 16 09:35:43 +0000 2018</td>
      <td>0.000</td>
      <td>0.802</td>
      <td>0.198</td>
      <td>RT @BBCWales: 🌼 Daffodils dance in the spring ...</td>
      <td>26</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0.4404</td>
      <td>Fri Mar 16 09:00:03 +0000 2018</td>
      <td>0.000</td>
      <td>0.847</td>
      <td>0.153</td>
      <td>💪 After having his leg amputated, @MarkSmithBB...</td>
      <td>27</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.6115</td>
      <td>Fri Mar 16 08:30:05 +0000 2018</td>
      <td>0.000</td>
      <td>0.840</td>
      <td>0.160</td>
      <td>🌸🌻🌺\nTake a look at some of the strangest, sca...</td>
      <td>28</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>29</th>
      <td>-0.4019</td>
      <td>Fri Mar 16 08:00:08 +0000 2018</td>
      <td>0.172</td>
      <td>0.828</td>
      <td>0.000</td>
      <td>😬🛰🌏 Brace yourselves... a Chinese space statio...</td>
      <td>29</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>470</th>
      <td>0.4650</td>
      <td>Fri Mar 16 21:05:04 +0000 2018</td>
      <td>0.102</td>
      <td>0.672</td>
      <td>0.226</td>
      <td>Despite a celebrated refugee settlement system...</td>
      <td>70</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>471</th>
      <td>0.0000</td>
      <td>Fri Mar 16 20:50:06 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>“She was an angel. She wanted to become a lawy...</td>
      <td>71</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>472</th>
      <td>-0.8020</td>
      <td>Fri Mar 16 20:35:08 +0000 2018</td>
      <td>0.310</td>
      <td>0.690</td>
      <td>0.000</td>
      <td>All “doors-off” helicopter flights have been h...</td>
      <td>72</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>473</th>
      <td>0.0000</td>
      <td>Fri Mar 16 20:20:07 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Nearly 3 in 4 teachers oppose letting staff ca...</td>
      <td>73</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>474</th>
      <td>0.3612</td>
      <td>Fri Mar 16 20:05:03 +0000 2018</td>
      <td>0.000</td>
      <td>0.878</td>
      <td>0.122</td>
      <td>“Stealing an instrument in New Orleans is like...</td>
      <td>74</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>475</th>
      <td>-0.2023</td>
      <td>Fri Mar 16 19:50:05 +0000 2018</td>
      <td>0.091</td>
      <td>0.909</td>
      <td>0.000</td>
      <td>One NYT reader's reaction to South Africa's fo...</td>
      <td>75</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>476</th>
      <td>-0.5574</td>
      <td>Fri Mar 16 19:35:05 +0000 2018</td>
      <td>0.153</td>
      <td>0.847</td>
      <td>0.000</td>
      <td>After Trump fired Rex Tillerson in a tweet, we...</td>
      <td>76</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>477</th>
      <td>0.5371</td>
      <td>Fri Mar 16 19:20:10 +0000 2018</td>
      <td>0.106</td>
      <td>0.603</td>
      <td>0.291</td>
      <td>The price French bulldogs pay for being so cut...</td>
      <td>77</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>478</th>
      <td>0.2263</td>
      <td>Fri Mar 16 19:05:04 +0000 2018</td>
      <td>0.000</td>
      <td>0.924</td>
      <td>0.076</td>
      <td>NASA had to set the record straight: Mark Kell...</td>
      <td>78</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>479</th>
      <td>-0.4588</td>
      <td>Fri Mar 16 18:55:07 +0000 2018</td>
      <td>0.218</td>
      <td>0.704</td>
      <td>0.077</td>
      <td>Where President Trump goes wrong on trade, and...</td>
      <td>79</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>480</th>
      <td>0.0000</td>
      <td>Fri Mar 16 18:45:09 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Ben Carson and David Shulkin remain in their c...</td>
      <td>80</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>481</th>
      <td>-0.5994</td>
      <td>Fri Mar 16 18:35:04 +0000 2018</td>
      <td>0.311</td>
      <td>0.546</td>
      <td>0.143</td>
      <td>Modern Love: He was struggling with an obscure...</td>
      <td>81</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>482</th>
      <td>0.0000</td>
      <td>Fri Mar 16 18:29:13 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>When Sheryl Sandberg’s book published 5 years ...</td>
      <td>82</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>483</th>
      <td>0.0000</td>
      <td>Fri Mar 16 18:20:05 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>In @NYTOpinion \n\nWuilly Arteaga, an exiled v...</td>
      <td>83</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>484</th>
      <td>0.0000</td>
      <td>Fri Mar 16 18:05:05 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>When Sheryl Sandberg’s book published 5 years ...</td>
      <td>84</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>485</th>
      <td>0.6369</td>
      <td>Fri Mar 16 17:50:04 +0000 2018</td>
      <td>0.000</td>
      <td>0.776</td>
      <td>0.224</td>
      <td>It’s a bold plan to wean Californians from the...</td>
      <td>85</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>486</th>
      <td>0.0000</td>
      <td>Fri Mar 16 17:35:05 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>In @NYTOpinion \n\nOp-Ed Columnist @DouthatNYT...</td>
      <td>86</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>487</th>
      <td>-0.5423</td>
      <td>Fri Mar 16 17:20:07 +0000 2018</td>
      <td>0.200</td>
      <td>0.800</td>
      <td>0.000</td>
      <td>Readers wrote in with their accounts of workpl...</td>
      <td>87</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>488</th>
      <td>0.0000</td>
      <td>Fri Mar 16 17:05:07 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>The Bollywood legend, Madhubala has been compa...</td>
      <td>88</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>489</th>
      <td>0.0000</td>
      <td>Fri Mar 16 16:50:06 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>A study confirms what news reports have sugges...</td>
      <td>89</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>490</th>
      <td>-0.2732</td>
      <td>Fri Mar 16 16:35:06 +0000 2018</td>
      <td>0.147</td>
      <td>0.761</td>
      <td>0.091</td>
      <td>Is your NCAA bracket still intact? Here's what...</td>
      <td>90</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>491</th>
      <td>-0.3818</td>
      <td>Fri Mar 16 16:20:07 +0000 2018</td>
      <td>0.115</td>
      <td>0.885</td>
      <td>0.000</td>
      <td>We visit the Kafkaesque Office of Administrati...</td>
      <td>91</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>492</th>
      <td>0.0000</td>
      <td>Fri Mar 16 16:05:07 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Our recap of the latest episode of "Atlanta" h...</td>
      <td>92</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>493</th>
      <td>0.0000</td>
      <td>Fri Mar 16 15:50:08 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>How to learn about Quebec's identity? Have a m...</td>
      <td>93</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>494</th>
      <td>0.0000</td>
      <td>Fri Mar 16 15:35:04 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Trump's new chief economic adviser is known fo...</td>
      <td>94</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>495</th>
      <td>-0.3818</td>
      <td>Fri Mar 16 15:25:07 +0000 2018</td>
      <td>0.110</td>
      <td>0.890</td>
      <td>0.000</td>
      <td>RT @NYTSports: Catch up on last night's NCAA t...</td>
      <td>95</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>496</th>
      <td>0.4767</td>
      <td>Fri Mar 16 15:15:09 +0000 2018</td>
      <td>0.000</td>
      <td>0.819</td>
      <td>0.181</td>
      <td>The prompt: “Draw an effective leader.” Both m...</td>
      <td>96</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>497</th>
      <td>0.0000</td>
      <td>Fri Mar 16 15:05:00 +0000 2018</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Since 1851, obituaries in The New York Times h...</td>
      <td>97</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>498</th>
      <td>-0.6597</td>
      <td>Fri Mar 16 14:55:07 +0000 2018</td>
      <td>0.256</td>
      <td>0.659</td>
      <td>0.085</td>
      <td>Snapchat shares fell 4% after Rihanna criticiz...</td>
      <td>98</td>
      <td>@NYTimes</td>
    </tr>
    <tr>
      <th>499</th>
      <td>-0.3612</td>
      <td>Fri Mar 16 14:45:00 +0000 2018</td>
      <td>0.111</td>
      <td>0.889</td>
      <td>0.000</td>
      <td>“Somebody must show that the Afro-American rac...</td>
      <td>99</td>
      <td>@NYTimes</td>
    </tr>
  </tbody>
</table>
<p>500 rows × 8 columns</p>
</div>




```python
news_sentiments.to_csv("Twitter_News_Mood.csv", index=False)
```


```python
plt.xlim(101, -1)


for user in target_users:
    dataframe = news_sentiments.loc[news_sentiments["User"] == user]
    plt.scatter(dataframe["Tweets Ago"],dataframe["Compound"],label = user)
    

plt.legend(bbox_to_anchor = (1,1))


plt.title("Sentiment Analysis of Media Tweets (11/5/2017)")
plt.xlabel("Tweets Ago")
plt.ylabel("Tweet Polarity")


plt.grid()

plt.savefig("Sentiment Analysis of Media Tweets")
plt.show()
```


![png](output_7_0.png)



```python
average_sentiment = news_sentiments.groupby("User")["Compound"].mean()
average_sentiment
```




    User
    @BBC        0.173452
    @CBS        0.314302
    @CNN       -0.100609
    @FoxNews   -0.208632
    @NYTimes   -0.072255
    Name: Compound, dtype: float64




```python
x_axis = np.arange(len(average_sentiment))
xlabels = average_sentiment.index
count = 0
for sentiment in average_sentiment:
    plt.text(count, sentiment+.01, str(round(sentiment,2)))
    count = count + 1
plt.bar(x_axis, average_sentiment, tick_label = xlabels, color = ['silver', 'b', 'y', 'g', 'c'])
#Set title, x axis label, and y axis label.
plt.title("Overall Sentiment of Media Tweets (11/5/2017)")
plt.xlabel("New Organizations")
plt.ylabel("Tweet Polarity")
plt.savefig("Overall Sentiment of Media Tweets")
plt.show()
```


![png](output_9_0.png)

